#include <stdio.h>
#include "passwd.h"


int main(int argc, char *argv[])
{
	// Handle options using getopt
	//
	// Process aut/reg
	// exit cleanly if all was well
	// else exit with a non-0 return val
	return 0;
}
